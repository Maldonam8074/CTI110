# CTI-110
# M5T1b: Initials
# Manuel Maldonado
# 10-11-2017

import turtle
win = turtle.Screen()
mo = turtle.Turtle()

# Otions
mo.pensize(4)
mo.pencolor("blue")
mo.shape("turtle")

# M shape

for i in [1,2]:
    mo.left(90)
    mo.forward(150)
    mo.right(150)
    mo.forward(100)
    mo.left(120)
    mo.forward(100)
    mo.right(150)
    mo.forward(150)
    mo.left(90)
    mo.up()
    mo.forward(100)
    mo.down()



win.mainloop()


