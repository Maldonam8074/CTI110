# CTI-110
# M5T1a: Shapes
# Manuel Maldonado
# 10-11-2017

import turtle
win = turtle.Screen()
mo = turtle.Turtle()

# Options
mo.pensize(4)
mo.pencolor("blue")
mo.shape("turtle")

# Square
for i in [0,1,2,3]:
    mo.forward(150)
    mo.left(90)

# Triangle, I used the forward as the base.
mo.forward(150)

for j in [0,1,2]:
    mo.forward(150)
    mo.left(120)

win.mainloop()



