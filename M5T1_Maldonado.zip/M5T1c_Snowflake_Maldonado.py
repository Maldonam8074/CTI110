# CTI-110
# M5T1c: Snowflake
# Manuel Maldonado
# 10-11-2017

import turtle
win = turtle.Screen()
mo = turtle.Turtle()

# Options
mo.pensize(4)
mo.pencolor("blue")
mo.shape("turtle")

# Snowflake

for i in range(10):
    for i in range(2):
        mo.forward(100)
        mo.right(60)
        mo.forward(100)
        mo.right(120)
    mo.right(36)    

win.mainloop()
